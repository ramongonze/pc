#!/usr/bin/env python
# coding: utf-8

# In[ ]:


exercicio_1(n)


# In[6]:


tupla = ()

for i in range (1, 10):
    tupla += i, i**2
    print ("o valor da tupla é:", tupla)


# In[ ]:


exercicio_2(3)


# In[3]:


tupla = ()
for i in range (1, 10):
    tupla += i, i**2, i**3
    print ("o valor da tupla é:", tupla)


# In[ ]:


exercicio_3() 


# In[38]:


tupla =  ('1','2','3','4','5','6','7','8','9','10')
tupla1 = tupla [:5]
tupla2 = tupla [5:11]
print ("o valor é :\n", tupla1, '\n', tupla2,)


# In[ ]:




